
Before do
  @project_root = File.expand_path(File.dirname(__FILE__) + '/../../')
end
